import argparse
import time
import asyncio
import urllib.parse
from playwright.async_api import async_playwright
import logging

# Loglama ayarları (Ekrana bilgi basmak için)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

async def user_task(user_id, target_url, context, semaphore, results, stats):
    """
    Her bir sanal kullanıcının yapacağı işlem.
    Semaphore ile aynı anda çalışan sekme (tab) sayısı kısıtlanmıştır.
    """
    async with semaphore:
        start_time = time.time()
        logging.info(f"Kullanıcı {user_id} sekme (tab) açıyor...")
        try:
            page = await context.new_page()
            # Yüklenmesi beklenecek maksimum süre: 20 saniye
            await page.goto(target_url, timeout=20000)
            
            # --- ETKİLEŞİM ŞABLONLARI ---
            # Sayfanın en altına kadar kaydırma (Scroll)
            # await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            
            end_time = time.time()
            duration = end_time - start_time
            logging.info(f"Kullanıcı {user_id} işlemi BAŞARIYLA tamamladı. Süre: {duration:.2f} saniye")
            
            results.append({"user_id": user_id, "status": "success", "duration": duration})
            stats["successful"] += 1
            
        except Exception as e:
            end_time = time.time()
            duration = end_time - start_time
            err_msg = str(e)[:100]
            logging.error(f"Kullanıcı {user_id} HATA ALDI: {err_msg}... Süre: {duration:.2f} saniye")
            
            results.append({"user_id": user_id, "status": "error", "duration": duration, "error": str(e)})
            stats["failed"] += 1
            
        finally:
            if 'page' in locals() and not page.is_closed():
                await page.close()
            
            stats["completed"] += 1
            print(f">>> ANLIK RAPOR: {stats['completed']}/{stats['total']} İşlem Bitti. (Başarılı: {stats['successful']} | Başarısız: {stats['failed']})")

async def run_stress_test(target_url, num_users, concurrent_users):
    print("="*60)
    print(f"PLAYWRIGHT STRES TESTİ BAŞLIYOR (ASYNC)")
    print(f"Hedef URL          : {target_url}")
    print(f"Toplam İstek Sayısı: {num_users}")
    print(f"Eşzamanlı Sekme    : {concurrent_users}")
    print("="*60)
    
    results = []
    stats = {"completed": 0, "successful": 0, "failed": 0, "total": num_users}
    
    # Eşzamanlılık kontrolü (Kuyruk mantığı - aynı anda max concurrent_users kadar sekme açılır)
    semaphore = asyncio.Semaphore(concurrent_users)
    
    start_total_time = time.time()
    
    async with async_playwright() as p:
        # Tek bir tarayıcı başlatıyoruz (RAM kullanımını minimuma indirmek için)
        browser = await p.chromium.launch(
            headless=True,
            args=[
                "--disable-gpu",
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-extensions",
                "--disable-software-rasterizer",
                "--single-process"
            ]
        )
        
        # Tüm sekmelerin içinde barınacağı tek bir bağlam (Incognito benzeri ortam)
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080}
        )
        
        # Bütün görevleri oluşturup asenkron olarak kuyruğa (semaphore'a) gönder
        tasks = []
        for i in range(num_users):
            tasks.append(asyncio.create_task(
                user_task(i+1, target_url, context, semaphore, results, stats)
            ))
            
        # Tüm görevlerin (toplam N isteğin) bitmesini bekle
        await asyncio.gather(*tasks)
        
        await context.close()
        await browser.close()
        
    end_total_time = time.time()
    total_duration = end_total_time - start_total_time
    
    # Sonuçları Analiz Et
    print("\n" + "="*60)
    print(f"TEST TAMAMLANDI")
    print(f"Toplam Geçen Süre : {total_duration:.2f} saniye")
    print(f"Başarılı İstekler : {stats['successful']}")
    print(f"Başarısız İstekler: {stats['failed']}")
    
    if stats['successful'] > 0:
        successful_durations = [r["duration"] for r in results if r["status"] == "success"]
        successful_durations.sort()
        avg_time = sum(successful_durations) / stats['successful']
        min_time = successful_durations[0]
        max_time = successful_durations[-1]
        
        # Basit p95 hesaplaması
        p95_index = max(0, int(stats['successful'] * 0.95) - 1)
        p95_time = successful_durations[p95_index]
        
        print("-" * 60)
        print("SÜRE İSTATİSTİKLERİ (Başarılı İstekler İçin):")
        print(f"Ortalama Süre   : {avg_time:.2f} saniye")
        print(f"En Hızlı İstek  : {min_time:.2f} saniye")
        print(f"En Yavaş İstek  : {max_time:.2f} saniye")
        print(f"p95 Süresi      : {p95_time:.2f} saniye")
        
    if stats['failed'] > 0:
        print("DİKKAT: Başarısız istekler var. Sunucu sınırına ulaşılmış veya aşılmış olabilir!")
    print("="*60)


def main():
    parser = argparse.ArgumentParser(description="Playwright Async Web Stres Test Aracı")
    parser.add_argument("--url", required=True, help="Test edilecek hedef URL")
    parser.add_argument("--users", type=int, default=100, help="Toplam gönderilecek istek/kullanıcı sayısı (Varsayılan: 100)")
    parser.add_argument("--concurrent", type=int, default=10, help="Aynı anda açılacak aktif sekme sayısı (Varsayılan: 10)")
    
    args = parser.parse_args()
    
    # URL Doğrulaması
    parsed_url = urllib.parse.urlparse(args.url)
    if not parsed_url.scheme or not parsed_url.netloc:
        print("HATA: Lütfen geçerli bir URL girin (Örn: https://example.com)")
        return
        
    asyncio.run(run_stress_test(args.url, args.users, args.concurrent))


if __name__ == "__main__":
    main()
